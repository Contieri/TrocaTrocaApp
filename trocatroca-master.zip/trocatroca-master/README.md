# TrocaTroca
An android app based on trading(books or games) between two people.

## Description
 Using a mechanics called "match", which consists of an agreement of what objects are going to be traded. Each user offers a product, in exchange for another product from a custom list defined by the user, if another person offers something from the desired custom list, and also wants the product the other is offering, the app will automatically notify both parties.
