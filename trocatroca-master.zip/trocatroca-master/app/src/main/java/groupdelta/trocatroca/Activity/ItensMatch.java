package groupdelta.trocatroca.Activity;

public class ItensMatch {

    private String meuItem, itemDesejado, usuario1, usuario2;
    private int imagem1, imagem2;

    public String getMeuItem() {
        return meuItem;
    }

    public void setMeuItem(String meuItem) {
        this.meuItem = meuItem;
    }

    public String getItemDesejado() {
        return itemDesejado;
    }

    public void setItemDesejado(String itemDesejado) {
        this.itemDesejado = itemDesejado;
    }

    public String getUsuario1() {
        return usuario1;
    }

    public void setUsuario1(String usuario1) {
        this.usuario1 = usuario1;
    }

    public String getUsuario2() {
        return usuario2;
    }

    public void setUsuario2(String usuário2) {
        this.usuario2 = usuário2;
    }

    public int getImagem1() {
        return imagem1;
    }

    public void setImagem1(int imagem1) {
        this.imagem1 = imagem1;
    }

    public int getImagem2() {
        return imagem2;
    }

    public void setImagem2(int imagem2) {
        this.imagem2 = imagem2;
    }

}
