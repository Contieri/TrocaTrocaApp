package groupdelta.trocatroca.Activity;

public class ItensAnuncios {

    private String meuItem, itemDesejado, descricao;
    private int imagem;

    public String getMeuItem() {
        return meuItem;
    }

    public void setMeuItem(String meuItem) {
        this.meuItem = meuItem;
    }

    public String getDescricao() {
        return descricao;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }

    public String getItemDesejado() {
        return itemDesejado;
    }

    public void setItemDesejado(String itemDesejado) {
        this.itemDesejado = itemDesejado;
    }

    public int getImagem() {
        return imagem;
    }

    public void setImagem(int imagem) {
        this.imagem = imagem;
    }
}
